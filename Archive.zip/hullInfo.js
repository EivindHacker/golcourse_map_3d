"use strict"
export const hullInfo = [null ,`
Åpningshullet er et meget langt par 5 hvor det å gå for greenen i to ikke er å anbefale. Unngår man bunkrene på utslaget og andreslaget er hullet overkommelig. En "grådig" bekk krysser på skrå i forkant green. Favoriser venstre side på innspill til greenen som heller fra venstre mot høyre.
<br><br>
Pro tips:<br>
Ikke være redd for bruke et ekstra slag kort av bekken hvis du har et langt innspill. Konservativt spill er ofte det lureste.
<br><br>
OBS. I enden av fairway, på høyden til høyre, er det et delvis skjult hus som kan nås, vær derfor forsiktig på innspilllet og hold til venstre.`];
